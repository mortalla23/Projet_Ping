package com.example.routes;

import com.example.SimpleApi;
import com.example.Websocket;
import com.example.Websocket2;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import static spark.Spark.*;
import java.util.ArrayList;
import java.util.List;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class MessageRoutes {

    public static void initRoutes(MongoCollection<Document> messages, MongoCollection<Document> conversations, MongoCollection<Document> compteurs) {
        // Endpoint pour récupérer les messages d'une conversation
        get("/conversations/:conversation_id/messages", (req, res) -> {
            res.type("application/json");
            int conversationId = Integer.parseInt(req.params(":conversation_id"));
            List<String> messagesList = new ArrayList<>();
            for (Document message : messages.find(Filters.eq("conversation_id", conversationId))) {
                messagesList.add(message.toJson());
            }
            if (messagesList.isEmpty()) {
                res.status(404);
                return "{\"error\": \"Aucun message trouvé pour cette conversation.\"}";
            }
            return messagesList;
        });
        
        // Endpoint pour ajouter un message
        post("/messages/add", (req, res) -> {
            res.type("application/json");
            try {
                String conversationIdParam = req.queryParams("conversation_id");
                String senderIdParam = req.queryParams("sender_id");
                String content = req.queryParams("content");

                if (conversationIdParam == null || senderIdParam == null || content == null ||
                    conversationIdParam.isEmpty() || senderIdParam.isEmpty() || content.isEmpty()) {
                    res.status(400);
                    return "{\"error\": \"Les paramètres 'conversation_id', 'sender_id', et 'content' sont requis.\"}";
                }

                int conversationId = Integer.parseInt(conversationIdParam);
                int senderId = Integer.parseInt(senderIdParam);
                int message_id = SimpleApi.getNextSequenceValue(compteurs,messages,"messages");

                // Ajouter un message à la collection
                Document message = new Document()
                        .append("id",message_id)
                        .append("conversation_id", conversationId)
                        .append("sender_id", senderId)
                        .append("content", content)
                        .append("created_at", new java.util.Date())
                        .append("is_read", false);

                messages.insertOne(message);

                 // Diffusion du message à tous les participants via WebSocket
                 Websocket.broadcastMessage(conversationId, message.toJson());
                 Websocket.broadcastNotification(conversationId, senderId, content);
                 Websocket2.broadcastMessage(conversationId, message.toJson());

                 
                //Mettre à jour le champ last_message_id dans la conversation
                conversations.updateOne(
                    Filters.eq("id", conversationId),
                    new Document("$set", new Document("last_message_id", message_id))
                );

                res.status(201);
                return "{\"message\": \"Message ajouté avec succès\"}";
            } catch (Exception e) {
                e.printStackTrace();
                res.status(500);
                return "{\"error\": \"Erreur interne\"}";
            }
        });

        // Endpoint pour marquer un message comme lu (is_read = true)
        post("/messages/mark_as_read", (req, res) -> {
            res.type("application/json");

            try {
                // Récupérer l'ID du message depuis les paramètres de la requête
                String messageIdParam = req.queryParams("message_id");

                // Vérifier que l'ID est présent et valide
                if (messageIdParam == null || messageIdParam.isEmpty()) {
                    res.status(400);
                    return "{\"error\": \"Le paramètre 'message_id' est requis.\"}";
                }

                int messageId = Integer.parseInt(messageIdParam);

                // Vérifier si le message existe
                Document message = messages.find(Filters.eq("id", messageId)).first();
                if (message == null) {
                    res.status(404);
                    return "{\"error\": \"Message introuvable.\"}";
                }

                // Mettre à jour le champ is_read à true
                messages.updateOne(
                    Filters.eq("id", messageId),
                    Updates.set("is_read", true)
                );

                // Retourner une réponse de succès
                res.status(200);
                return "{\"message\": \"Le message a été marqué comme lu avec succès.\"}";
            } catch (NumberFormatException e) {
                res.status(400);
                return "{\"error\": \"L'ID du message doit être un entier valide.\"}";
            } catch (Exception e) {
                res.status(500);
                return String.format("{\"error\": \"Une erreur interne s'est produite : %s\"}", e.getMessage());
            }
        });
    //Endpoint pour récupérer un message à partir de son ID
        get("/messages/:message_id", (req, res) -> {
            res.type("application/json");

            // Récupérer l'ID du message depuis les paramètres de l'URL
            String messageIdParam = req.params(":message_id");

            try {
                // Convertir l'ID du message en entier
                int messageId = Integer.parseInt(messageIdParam);

                // Rechercher le message par ID dans la collection `messages`
                Document message = messages.find(Filters.eq("id", messageId)).first();

                if (message == null) {
                    res.status(404);
                    return "{\"error\": \"Message introuvable.\"}";
                }

                // Retourner le message en JSON
                res.status(200);
                return message.toJson();

            } catch (NumberFormatException e) {
                res.status(400);
                return "{\"error\": \"L'ID du message doit être un entier.\"}";
            } catch (Exception e) {
                res.status(500);
                return String.format("{\"error\": \"Une erreur interne s'est produite : %s\"}", e.getMessage());
            }
        });
    }
}
