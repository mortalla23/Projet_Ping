package com.example.routes;

import com.example.SimpleApi;
import com.mongodb.client.MongoCollection;

import org.bson.BsonDateTime;
import org.bson.Document;
import static spark.Spark.*;
import java.util.ArrayList;
import java.util.List;
import com.mongodb.client.model.Filters;

public class ConversationRoutes {

    public static void initRoutes(MongoCollection<Document> conversations,MongoCollection<Document> users, MongoCollection<Document> participants, MongoCollection<Document> compteurs, MongoCollection<Document> messages) {
        // Endpoint pour récupérer toutes les conversations
        get("/conversations/display", (req, res) -> {
            res.type("application/json");
            List<String> result = new ArrayList<>();
            for (Document doc : conversations.find()) {
                result.add(doc.toJson());
            }
            return result;
        });

        
        // Endpoint pour ajouter une conversation
            post("/conversations/add", (req, res) -> {
                res.type("application/json");
            
                // Récupérer les paramètres
                String isPublicParam = req.queryParams("is_public");
                //String lastMessageIdParam = req.queryParams("last_message_id");
                String userIdParam = req.queryParams("user_id"); // ID de l'utilisateur
            
                // Valider les paramètres
                if ( isPublicParam == null ||  userIdParam == null) {
                    res.status(400);
                    return "{\"error\": \"Les paramètres 'id', 'is_public', 'last_message_id' et 'user_id' sont requis.\"}";
                }
            
                try {
                    int id = SimpleApi.getNextSequenceValue(compteurs,conversations,"conversations");
                    boolean isPublic = Boolean.parseBoolean(isPublicParam);
                    int lastMessageId = 0;
                    int userId = Integer.parseInt(userIdParam);
            
                    // Vérifier si l'utilisateur existe dans la collection `users`
                    Document user = users.find(Filters.eq("id", userId)).first();
                    if (user == null) {
                        res.status(404);
                        return "{\"error\": \"Utilisateur introuvable.\"}";
                    }
            
                    // Créer le document pour la conversation
                    Document conversation = new Document()
                        .append("id", id) // ID unique
                        .append("is_public", isPublic) // Champ is_public
                        .append("created_at", new BsonDateTime(System.currentTimeMillis())) // Champ created_at
                        .append("last_message_id", lastMessageId); // Champ last_message_id
            
                    // Insérer dans la collection MongoDB
                    conversations.insertOne(conversation);
            
                    // Ajouter l'entrée dans la collection `participants`
                    Document participant = new Document()
                        .append("conversation_id", id) // ID de la conversation
                        .append("user_id", userId); // ID de l'utilisateur
            
                    participants.insertOne(participant);
            
                    // Retourner une réponse avec l'ID de la nouvelle conversation
                    res.status(201);
                    return String.format(
                        "{\"message\": \"Conversation et participation ajoutées\", \"conversation_id\": %d, \"user_id\": %d}",
                        id, userId
                    );
                } catch (NumberFormatException e) {
                    res.status(400);
                    return "{\"error\": \"Les paramètres 'id', 'last_message_id' et 'user_id' doivent être des entiers.\"}";
                } catch (Exception e) {
                    res.status(500);
                    return String.format("{\"error\": \"Une erreur interne s'est produite : %s\"}", e.getMessage());
                }
            });

             
        //Ajouter un utilisateur à une conversation
            post("/conversations/add_user", (req, res) -> {
                res.type("application/json");
            
                // Récupérer les paramètres de la requête
                String conversationIdParam = req.queryParams("conversation_id");
                String userIdParam = req.queryParams("user_id");
            
                // Valider les paramètres
                if (conversationIdParam == null || userIdParam == null) {
                    res.status(400);
                    return "{\"error\": \"Les paramètres 'conversation_id' et 'user_id' sont requis.\"}";
                }
            
                try {
                    int conversationId = Integer.parseInt(conversationIdParam);
                    int userId = Integer.parseInt(userIdParam);
            
                    // Vérifier si la conversation existe
                    Document conversation = conversations.find(Filters.eq("id", conversationId)).first();
                    if (conversation == null) {
                        res.status(404);
                        return "{\"error\": \"Conversation introuvable.\"}";
                    }
            
                    // Vérifier si l'utilisateur existe dans la collection `users`
                    Document user = users.find(Filters.eq("id", userId)).first();
                    if (user == null) {
                        res.status(404);
                        return "{\"error\": \"Utilisateur introuvable.\"}";
                    }
            
                    // Vérifier si l'utilisateur est déjà participant
                    Document existingParticipant = participants.find(
                        Filters.and(
                            Filters.eq("conversation_id", conversationId),
                            Filters.eq("user_id", userId)
                        )
                    ).first();
            
                    if (existingParticipant != null) {
                        res.status(400);
                        return "{\"error\": \"L'utilisateur est déjà participant de cette conversation.\"}";
                    }
            
                    // Ajouter l'utilisateur à la conversation dans la collection `participants`
                    Document participant = new Document()
                        .append("conversation_id", conversationId)
                        .append("user_id", userId);
            
                    participants.insertOne(participant);
            
                    // Retourner une réponse de succès
                    res.status(201);
                    return String.format(
                        "{\"message\": \"Utilisateur ajouté à la conversation\", \"conversation_id\": %d, \"user_id\": %d}",
                        conversationId, userId
                    );
                } catch (NumberFormatException e) {
                    res.status(400);
                    return "{\"error\": \"Les paramètres 'conversation_id' et 'user_id' doivent être des entiers.\"}";
                } catch (Exception e) {
                    res.status(500);
                    return String.format("{\"error\": \"Une erreur interne s'est produite : %s\"}", e.getMessage());
                }
            });

    }
}
