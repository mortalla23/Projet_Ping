package com.example.routes;

import com.mongodb.client.MongoCollection;
import org.bson.Document;
import static spark.Spark.*;
import java.util.ArrayList;
import java.util.List;
import com.mongodb.client.model.Filters;
public class UserRoutes {

    public static void initRoutes(MongoCollection<Document> users, MongoCollection<Document> participants, MongoCollection<Document> conversations) {
        // Endpoint pour récupérer tous les utilisateurs
        get("/users/all/display", (req, res) -> {
            res.type("application/json");
            List<String> result = new ArrayList<>();
            for (Document user : users.find()) {
                result.add(user.toJson());
            }
            return result;
        });

        
        // Endpoint pour récupérer un utilisateur par ID
        get("/users/:user_id", (req, res) -> {
            res.type("application/json");
            int userId = Integer.parseInt(req.params(":user_id"));
            Document user = users.find(Filters.eq("id", userId)).first();
            if (user == null) {
                res.status(404);
                return "{\"error\": \"Utilisateur introuvable.\"}";
            }
            return user.toJson();
        });

       // Endpoint pour rechercher des utilisateurs par partie de leur username
       get("/users/search/:username", (req, res) -> {
        res.type("application/json");

        // Récupérer la partie du username depuis les paramètres de la requête
        String usernameQuery = req.params(":username");

        try {
            // Rechercher tous les utilisateurs dont le username commence par la partie saisie (insensible à la casse)
            List<String> usersList = new ArrayList<>();
            for (Document user : users.find(Filters.regex("username", "^" + usernameQuery, "i"))) {
                usersList.add(user.toJson());
            }

            // Vérifier si des résultats ont été trouvés
            if (usersList.isEmpty()) {
                res.status(404);
                return "{\"error\": \"Aucun utilisateur trouvé.\"}";
            }

            // Retourner les utilisateurs correspondants
            res.status(200);
            return usersList;
        } catch (Exception e) {
            res.status(500);
            return String.format("{\"error\": \"Une erreur interne s'est produite : %s\"}", e.getMessage());
        }
    });


        //Récupérer les conversations où l'utilisateur est participant
            get("/users/:user_id/conversations", (req, res) -> {
                res.type("application/json");

                // Récupérer l'ID de l'utilisateur depuis la requête
                int userId = Integer.parseInt(req.params(":user_id"));

                // Rechercher toutes les participations de l'utilisateur
                List<Integer> conversationIds = new ArrayList<>();
                for (Document participant : participants.find(Filters.eq("user_id", userId))) {
                    conversationIds.add(participant.getInteger("conversation_id"));
                }

                if (conversationIds.isEmpty()) {
                    res.status(404);
                    return "{\"error\": \"Aucune conversation trouvée pour cet utilisateur.\"}";
                }

                // Rechercher les conversations associées
                List<String> conversationsList = new ArrayList<>();
                for (Document conversation : conversations.find(Filters.in("id", conversationIds))) {
                    conversationsList.add(conversation.toJson());
                }

                return conversationsList;
            });
    }
}
