package com.example.routes;

import com.mongodb.client.MongoCollection;
import org.bson.Document;
import static spark.Spark.*;
import java.util.ArrayList;
import java.util.List;
import com.mongodb.client.model.Filters;

public class ParticipantRoutes {

    public static void initRoutes(MongoCollection<Document> participants) {
        // Endpoint pour récupérer les participants d'une conversation
        get("/conversations/:conversation_id/participants", (req, res) -> {
            res.type("application/json");
            int conversationId = Integer.parseInt(req.params(":conversation_id"));
            List<String> result = new ArrayList<>();
            for (Document participant : participants.find(Filters.eq("conversation_id", conversationId))) {
                result.add(participant.toJson());
            }
            return result;
        });
    }
}
