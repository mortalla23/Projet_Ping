package com.example;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import org.bson.Document;

@WebSocket
public class Websocket2 {

    // Liste des sessions pour chaque conversation
    private static final Map<Integer, List<Session>> sessionsByConversation = new HashMap<>();

    @OnWebSocketConnect
    public void onConnect(Session session) {
        System.out.println("Nouvelle connexion WebSocket : " + session.getRemoteAddress());
    }

    @OnWebSocketClose
    public void onClose(Session session, int statusCode, String reason) {
        System.out.println("Connexion WebSocket fermée : " + reason);

        // Supprimer la session de toutes les conversations
        for (List<Session> sessions : sessionsByConversation.values()) {
            sessions.remove(session);
        }
    }

    @OnWebSocketMessage
    public void onMessage(Session session, String message) {
        System.out.println("Message reçu : " + message);

        // Exemple : Ajouter un client à une conversation
        try {
            Map<String, Object> data = Document.parse(message);
            int conversationId = (int) data.get("conversation_id");

            // Ajouter la session uniquement si elle n'est pas déjà inscrite
            sessionsByConversation
                .computeIfAbsent(conversationId, k -> new CopyOnWriteArrayList<>())
                .stream()
                .filter(existingSession -> existingSession.equals(session))
                .findFirst()
                .orElseGet(() -> {
                    sessionsByConversation.get(conversationId).add(session);
                    try {
                        session.getRemote().sendString("{\"message\": \"Inscription à la conversation réussie.\"}");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return session;
                });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthode pour diffuser un message à tous les clients d'une conversation
    public static void broadcastMessage(int conversationId, String message) {
        List<Session> sessions = sessionsByConversation.get(conversationId);
        if (sessions != null) {
            // Nettoyer les sessions fermées
            sessions.removeIf(session -> !session.isOpen());

            for (Session session : sessions) {
                try {
                 // Convertir la chaîne JSON en Document
                 Document messageDocument = Document.parse(message);
                    
                 // Ajouter type et createdAt au document
                 messageDocument.append("type", "newMessage"); // Ajouter le type
                 messageDocument.append("createdAt", new Date().toString()); // Ajouter la date
                 
                 // Convertir le document en JSON
                 String messageWithDate = messageDocument.toJson();
        session.getRemote().sendString(messageWithDate);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}