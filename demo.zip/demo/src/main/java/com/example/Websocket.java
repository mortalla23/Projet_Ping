package com.example;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import org.json.JSONArray;
import org.json.JSONObject;
import org.bson.Document;

@WebSocket  
public class Websocket {

    // Map utilisateur → Liste des sessions WebSocket
    private static final Map<Integer, List<Session>> sessionsByUser = new HashMap<>();

    @OnWebSocketConnect
    public void onConnect(Session session) {
        System.out.println("Nouvelle connexion WebSocket : " + session.getRemoteAddress());
    }

    @OnWebSocketClose
    public void onClose(Session session, int statusCode, String reason) {
        System.out.println("Connexion WebSocket fermée : " + reason);

        // Supprimer la session de toutes les listes d'abonnements
        for (List<Session> sessions : sessionsByUser.values()) {
            sessions.remove(session);
        }
    }

    @OnWebSocketMessage
public void onMessage(Session session, String message) {
    System.out.println("Message reçu : " + message);

    try {
        Map<String, Object> data = Document.parse(message);

        if (data.containsKey("action") && "subscribe".equals(data.get("action")) && data.containsKey("user_id")) {
            int userId = Integer.parseInt((String) data.get("user_id"));
            sessionsByUser.computeIfAbsent(userId, k -> new CopyOnWriteArrayList<>()).add(session);
            System.out.println("Je viens là");
           try {
    session.getRemote().sendString("{\"message\": \"Abonnement réussi à l'utilisateur " + userId + ".\"}");
} catch (IOException e) {
    System.err.println("Erreur d'envoi : " + e.getMessage());
    e.printStackTrace();
}
        } else {
            session.getRemote().sendString("{\"error\": \"Paramètres invalides.\"}");
        }
        
    } catch (Exception e) {
        System.err.println("Erreur dans le traitement du message WebSocket : " + e.getMessage());
        e.printStackTrace();
    }
}

// Méthode pour diffuser un message à tous les participants d'une conversation
public static void broadcastMessage(int conversationId, String messageJson) {
    List<Integer> participants = getParticipantsForConversation(conversationId); // Récupérer les participants
    System.out.println("Participants de la conversation " + conversationId + ": " + participants);

    for (int userId : participants) {
        List<Session> sessions = sessionsByUser.get(userId);
        
        if (sessions != null) {
            // Supprimer les sessions fermées
            sessions.removeIf(session -> !session.isOpen());
            
            for (Session session : sessions) {
                try {
                    // Convertir la chaîne JSON en Document
                    Document messageDocument = Document.parse(messageJson);
                    
                    // Ajouter type et createdAt au document
                    messageDocument.append("type", "newMessage"); // Ajouter le type
                    messageDocument.append("createdAt", new Date().toString()); // Ajouter la date
                    
                    // Convertir le document en JSON
                    String messageWithDate = messageDocument.toJson();
                    
                    // Envoyer le message à la session
                    session.getRemote().sendString(messageWithDate);
                    System.out.println("Message envoyé : " + messageWithDate);
                } catch (Exception e) {
                    System.err.println("Erreur lors de l'envoi du message à la session : " + e.getMessage());
                }
            }
        }
    }

}

    
   
    
    private static List<Integer> getParticipantsForConversation(int conversationId) {
        List<Integer> participants = new ArrayList<>();
        HttpURLConnection connection = null;
        try {
            String url = "http://localhost:8080/conversations/" + conversationId + "/participants";
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
        
            if (connection.getResponseCode() == 200) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String response = reader.lines().collect(Collectors.joining("\n"));
                    
                    // Convertir la réponse en JSONArray
                    JSONArray jsonArray = new JSONArray(response);
                    
                    // Parcourir le JSONArray pour extraire les user_id
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject participant = jsonArray.getJSONObject(i);
                        participants.add(participant.getInt("user_id"));
                    }
                }
            } else {
                System.err.println("Erreur lors de l'appel à l'API : " + connection.getResponseCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }         
        return participants;
    }

    public static void broadcastNotification(int conversationId, int senderId, String message) {
        // Récupérer le nom de l'expéditeur à partir de l'ID
        String senderName = getSenderName(senderId);
        if (senderName == null) {
            System.err.println("Impossible de récupérer le nom pour senderId : " + senderId);
            return; // Ne pas continuer si l'utilisateur est introuvable
        }
    
        // Récupérer les participants de la conversation
        List<Integer> participants = getParticipantsForConversation(conversationId);
    
        for (int userId : participants) {
            List<Session> sessions = sessionsByUser.get(userId);
            if (sessions != null) {
                sessions.removeIf(session -> !session.isOpen()); // Nettoyer les sessions fermées
    
                for (Session session : sessions) {
                    try {
                        String notification = new Document()
                            .append("type", "notification")
                            .append("conversationId", conversationId)
                            .append("sender", senderName)
                            .append("content", message)
                            .append("createdAt", new Date().toString())
                            .toJson();
                        session.getRemote().sendString(notification);
                    } catch (Exception e) {
                        System.err.println("Erreur lors de l'envoi de la notification à une session : " + e.getMessage());
                    }
                }
            }
        }
    }
    private static String getSenderName(int senderId) {
        try {
            // Construire l'URL de la requête
            String url = "http://localhost:8080/users/" + senderId;
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
    
            // Vérifier le code de réponse
            if (connection.getResponseCode() == 200) {
               
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String response = reader.lines().collect(Collectors.joining("\n"));
                     
    
                // Extraire le champ "username" du document JSON
                Document user = Document.parse(response);
                return user.getString("username"); // Remplacez "username" par le champ réel dans votre base
           } } else {
                System.err.println("Erreur lors de la récupération de l'utilisateur : " + connection.getResponseCode());
            }
    
            connection.disconnect();
        } catch (Exception e) {
            System.err.println("Exception lors de la récupération du senderName : " + e.getMessage());
        }
    
        return null; // Retourner null si une erreur survient
    }
        
    
}
