package com.example;

import com.example.routes.ConversationRoutes;
import com.example.routes.MessageRoutes;
import com.example.routes.UserRoutes;
import com.example.routes.ParticipantRoutes;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;
import com.mongodb.client.model.Updates;
import static com.mongodb.client.model.Filters.eq;


import org.bson.Document;
import static spark.Spark.*;

public class SimpleApi {

    public static void main(String[] args) {
        // Configuration du port
        port(8080);


        // Enregistrement du WebSocket avant les routes
        webSocket("/ws", Websocket.class);
        webSocket("/ws2", Websocket2.class); // Enregistrement de Websocket2


        // Connexion à MongoDB
        String uri = "mongodb://root:rootpassword@192.168.1.59:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("bdd_ping");

        // Collections MongoDB
        MongoCollection<Document> conversations = database.getCollection("conversations");
        MongoCollection<Document> messages = database.getCollection("messages");
        MongoCollection<Document> users = database.getCollection("users");
        MongoCollection<Document> participants = database.getCollection("participants");
        MongoCollection<Document> compteurs = database.getCollection("compteurs");

        initializeCounters(compteurs);

        

        // Configuration des CORS
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }

            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }

            return "OK";
        });

        before((request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            response.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
        });

        // Initialisation des routes
        ConversationRoutes.initRoutes(conversations,users, participants,compteurs,messages);
        MessageRoutes.initRoutes(messages,conversations,compteurs);
        UserRoutes.initRoutes(users,participants,conversations);
        ParticipantRoutes.initRoutes(participants);

        // Logs d'initialisation
        System.out.println("API MongoDB et WebSockets démarrés sur :");
        System.out.println("  - HTTP : http://localhost:8080");
        System.out.println("  - WebSocket 1 : ws://localhost:8080/ws");
        System.out.println("  - WebSocket 2 : ws://localhost:8080/ws2");
        
    }

    public static int getNextSequenceValue(MongoCollection<Document> counters, MongoCollection<Document> targetCollection, String collectionName) {
        while (true) {
            // Rechercher et incrémenter le compteur
            Document updatedCounter = counters.findOneAndUpdate(
                eq("_id", collectionName),
                Updates.inc("sequence_value", 1), // Incrémenter de 1
                new FindOneAndUpdateOptions().returnDocument(ReturnDocument.AFTER) // Retourner la valeur mise à jour
            );
            

            // Si le compteur est null, lever une exception (car il est supposé exister)
            if (updatedCounter == null) {
                throw new IllegalStateException("Le compteur pour la collection " + collectionName + " n'existe pas.");
            }

            // Obtenir la nouvelle valeur du compteur
            int newId = updatedCounter.getInteger("sequence_value");

            // Vérifier si l'ID est déjà utilisé dans la collection cible
            Document existingDocument = targetCollection.find(eq("id", newId)).first();
            if (existingDocument == null) {
                // Si l'ID n'est pas utilisé, le retourner
                return newId;
            }

            // Log pour débogage (optionnel)
            System.out.println("ID déjà utilisé : " + newId + ". Génération d'un nouvel ID...");
        }
    }

    public static void initializeCounters(MongoCollection<Document> counters) {
        String[] collections = {"messages", "users", "conversations", "participants"};
        for (String collectionName : collections) {
            if (counters.find(eq("_id", collectionName)).first() == null) {
                counters.insertOne(new Document("_id", collectionName).append("sequence_value", 0));
                System.out.println("Compteur initialisé pour la collection : " + collectionName);
            }
        }
    }
}
